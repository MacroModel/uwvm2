from pathlib import Path
import hashlib,json,os

D=Path(__file__).parent
def sha(p):
    with Path(p).open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
load=lambda n:json.loads((D/n).read_text())
q=load("ram-native-v1-qualified.json");g=load("guard-ram-native-v1.json")
a=load("analysis-compile-qualified-v1.json");ag=load("guard-analysis-compile-v1.json")
n=load("ram-native-v1-results.json")
v=load("generation-native-v2-qualified.json");vg=load("guard-generation-native-v2.json")
vn=load("generation-native-v2-results.json");eq=load("generation-v2-source-equivalence.json")
base=load("syntax-overlay-v1.json"); final=load("syntax-overlay-generation-v2.json")
assert q["passed"] and q["native_runs"]==q["fresh_native_runs"]==24 and q["reused_unchanged_native_runs"]==0
assert v["passed"] and v["fresh_native_cases"]==v["genuine_generation_2_cases"]==4 and v["frontend_checks"]==2
for proof in (g,vg,ag):
    assert proof["passed"] and proof["parent_events_unchanged"] and all(p["pidfd_retired"] for p in proof["processes"])
assert g["ram_disposable_products_retired"] and vg["ram_disposable_products_retired"]
assert a["passed"] and len(a["rows"])==16
assert sha(D/"ram-native-v1-results.json")==q["results_sha256"]
assert sha(D/"generation-native-v2-results.json")==v["results_sha256"]
assert sha(D/"generation_native_regression-v2.py")==v["controller_sha256"]
assert sha(D/"guard_generation_native-v2.py")==vg["guard_sha256"]
assert sha(D/"syntax-overlay-v1.json")==q["source_manifest_sha256"]==a["source_manifest_sha256"]==eq["old_manifest_sha256"]
assert sha(D/"syntax-overlay-generation-v2.json")==v["source_manifest_sha256"]==eq["new_manifest_sha256"]
assert v["base_native_qualification_sha256"]==sha(D/"ram-native-v1-qualified.json")
assert v["source_equivalence_sha256"]==sha(D/"generation-v2-source-equivalence.json")
assert eq["passed"] and eq["unchanged_inputs"]==base and len(base)==42 and len(final)==44
assert eq["added_inputs"]=={k:h for k,h in final.items() if k not in base} and all(final[k]==h for k,h in base.items())
native=[r for r in n["rows"] if r["actual_native_runtime_execution"]]
extra=[r for r in vn["rows"] if r["actual_native_runtime_execution"]]
assert len(native)==24 and all(r["passed"] for r in native)
assert len(extra)==4 and all(r["passed"] and r["actual_hot_replacement_generation_2"] and r["actual_private_effective_body_owner"] and r["original_committed_callback_after_discard"] for r in extra)
assert sum(r["compiler_frontend_only"] and r["passed"] for r in vn["rows"])==2
for collection,suffix in ((n["rows"],"ram-native-v1"),(vn["rows"],"generation-v2")):
    for row in collection:
        log=D/(row["repo"]+"-"+row["stage"]+"-"+suffix+".log")
        assert sha(log)==row["log_sha256"]
assert g["cgroup"]==vg["cgroup"]==ag["cgroup"]
fixtures=lambda rows:sum("-assemble" in r["stage"] or "-validate" in r["stage"] for r in rows)
assert len(a["wasm_data_fixture_checks"])==8 and fixtures(n["rows"])==28 and fixtures(vn["rows"])==4
report=dict(round="r40",implemented="genuine private final full-code owner handoff",
    source_manifest_sha256=sha(D/"syntax-overlay-generation-v2.json"),source_files=44,
    base_source_manifest_sha256=sha(D/"syntax-overlay-v1.json"),unchanged_base_source_files=42,
    fresh_linux_native_cases=28,reused_native_cases=0,fresh_frontend_checks=18,
    frontend_target_os=["linux","windows","freebsd","macos"],additional_linux_test_frontend_checks=2,
    wasm_frontend_data_checks=8,native_fixture_data_checks=32,genuine_generation_2_native_cases=4,
    native_qualification_sha256=sha(D/"ram-native-v1-qualified.json"),native_guard_sha256=sha(D/"guard-ram-native-v1.json"),
    generation_qualification_sha256=sha(D/"generation-native-v2-qualified.json"),generation_guard_sha256=sha(D/"guard-generation-native-v2.json"),
    frontend_qualification_sha256=sha(D/"analysis-compile-qualified-v1.json"),frontend_guard_sha256=sha(D/"guard-analysis-compile-v1.json"),
    source_equivalence_sha256=sha(D/"generation-v2-source-equivalence.json"),
    actual_engine_context_owners_transferred_privately=True,original_typed_target_allocation_preserved=True,
    original_safe_point_bitmap_allocations_preserved=True,pending_range_listener_detached_before_owner_move=True,
    native_endpoint_observer_staged_only=True,live_native_seal_issued=False,genuine_final_owners_rechecked_after_physical_join=True,
    transferred_effective_body_is_uncommitted_parser_data=True,generation_greater_than_one_native_handoff_case_tested=True,
    original_actual_committed_callback_after_candidate_discard=17,
    owned_peak_rss_bytes=max(g["owned_peak_aggregate_rss_upper_bytes"],vg["owned_peak_aggregate_rss_upper_bytes"]),
    cgroup_peak_bytes=max(g["cgroup_peak_bytes"],vg["cgroup_peak_bytes"]),
    owned_ram_peak_bytes=max(g["ram_peak_allocated_bytes"],vg["ram_peak_allocated_bytes"]),
    owned_native_processes_reaped=len(g["processes"])+len(vg["processes"]),owned_frontend_processes_reaped=len(ag["processes"]),
    all_owned_processes_reaped=True,owned_ram_products_deleted=True,parent_memory_events_unchanged=True,
    original_persistent_four_os_suite_admitted=False,original_storage_policy_unchanged=True,original_cgroup=g["cgroup"],
    native_other_os_completed_this_round=False,source_scope="44 frozen delta files over authenticated unchanged R34 dependencies; 42 base files unchanged",
    source_initializer_serial_issued=False,source_seal_issued=False,world_publication=False,
    restored_worker_startup=False,guest_replay=False,wasm_and_wasip1_same_stop_required=True,asm_vm_or_host_context_granted=False)
text="""# R40：真实 full-code owner 的私有交接

uwvm2 和 uwvm2-ros 已同步实现候选内部的真实所有权交接。所有资源、dispatch、间接调用、root 和私有 worker 检查成功后，将真实 finalizeObject 成功的 LLVM engine/context、compiler local metadata、typed target 数组、有效 body owner 和 frozen native endpoint observer 移入 R39 已分配的最终 full-runtime 记录。

typed target 数组直接移动同一分配，保持 LLVM IR 已嵌入的地址；safe-point view 继续指向同一 bitmap。原 staged 对象不再拥有 engine/context/local metadata/typed targets，只保留用于比较的实际交接地址和真实入口 DATA。交接后检查 FINAL owner 的实际资源、source/profile control block、dense/function/generation/plan、CFI、完整槽位和地址保持，再允许准备成功。execution drain 与真实 OS/TLS join 后再次检查这些 FINAL owner。

pending range listener 在 engine 活着时先 detach，避免 FINAL publication 比 staged 对象先销毁后，listener 析构再访问已释放 engine。诊断 range/provenance 保留为未提交 DATA，未注册全局范围。native endpoint observer 移入 FINAL owner 后仍是 staged-only/frozen、epoch 0、LIVE seal false，helpers/raw adapter 没有 Wasm ASM 调试权限。候选的私有解析 body 仍是 uncommitted source DATA，未伪装成 hot-replacement commit。

新增准备诊断 runtime_full_code_owners_transferred_privately、runtime_full_code_targets_allocation_preserved 及 module/function/effective-body 计数；新失败枚举 full_code_owner_handoff_declined 追加在末尾，保留旧枚举值。退休结果 full_code_owners_rechecked_after_physical_join 只在真实物理 join 后成功复核时设置。

| 本轮验证 | 结果 |
|---|---:|
| 两仓库 Linux 测试/runtime 与 Windows/FreeBSD/macOS runtime 前端 | 16 项全新检查通过 |
| 新增 generation 2 测试的 Linux 前端 | 2 项全新检查通过 |
| 前端阶段 Wasm 组装／validator | 8 项通过 |
| 原生阶段 Wasm 组装／validator | 32 项通过 |
| Linux LLVM full 基础原生回归 | 24/24 全新用例通过 |
| 真实 generation 2 的原生交接用例 | 4/4 全新用例通过 |
| 本轮其他 OS 原生 | 未执行 |

基础 24 个原生用例覆盖 core、WASIp1、完整单实例、preload，以及普通／间接调用和 instruction/unwind 策略。两仓库 runtime 和 host API 均重新构建、真实链接 LLVM。检查候选准备后的真实所有权及地址保持、旧线程退休前拒绝、body/TLS 等待、实际物理 join 后复核、candidate 保留与丢弃、原 source/epoch 与原世界继续可用。

新增 4 个用例在真实暂停的两 worker cohort 上，通过现有热替换 API 将未在执行的 callback 函数实际提交到 generation 2（i32.const 17）。准备候选时验证恰好 1 个真实 effective-body owner 已移入 FINAL 记录；退休与物理 join 后再次复核；丢弃候选后运行原世界，原有主函数仍返回 42，真实已提交 callback 返回 17。两个仓库分别执行 instruction/unwind。测试未伪造 generation、commit、publication 或 LIVE seal，也未执行恢复后的候选世界。

编译和运行都在原 SSH Linux 64 GiB cgroup，产物仅写入本轮独立 tmpfs。768 MiB RAM 文件、6 GiB 自有 RSS 和共享 cgroup 60 GiB 停止线维持。所有自有进程已回收、RAM 产物已删除，父 memory.events 未变。原持久四 OS suite 的磁盘/inode 门槛未降低，macOS 本机 2 GiB 限制保留。基础 42 个冻结输入逐字节不变，只新增两个 generation 2 测试源文件，最终范围为 44 个文件叠加未变 R34 依赖。前端检查不能代表其他 OS 的原生运行；本轮未覆盖其他 agent 修改的整个 checkout。

**实际联合 world 发布、恢复 worker 启动和 guest replay 仍未接通。** 后续需要在真实共同提交中完成 source/initializer serial/GC/WASIp1/代码身份/native LIVE adoption，再让完整新 worker cohort 在 closed startup generation 下安装真实 roots/ledgers/participants，确认 ALL seed 后开放 admission 并回放。Wasm 与 WASIp1 必须在同一实际停止点一起 checkpoint；外部文件内容和 I/O 副作用不会回滚。
"""
for name,value in (("wasip1_full_code_handoff_r40_test_report.json",json.dumps(report,indent=2)+"\n"),
                   ("wasip1_full_code_handoff_r40_test_report.md",text)):
    with (D/name).open("x") as f:f.write(value);f.flush();os.fsync(f.fileno())
print(json.dumps(report))
